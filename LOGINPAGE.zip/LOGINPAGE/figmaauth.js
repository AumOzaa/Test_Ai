// FIGMA ANALYZER AUTHENTICATION CONTROLLER
const authCheck = firebase.auth().onAuthStateChanged((user) => {
    if (!user) {
        authCheck(); // Unsubscribe the listener
        window.location.href = "login.html";
    } else {
        document.getElementById('userEmail').textContent = user.email;
    }
});

document.getElementById('signOutBtn').addEventListener('click', () => {
    firebase.auth().signOut().then(() => {
        window.location.href = 'login.html';
    });
});