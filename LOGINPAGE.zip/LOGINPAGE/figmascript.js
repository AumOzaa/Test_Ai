document.addEventListener("DOMContentLoaded", () => {
    // DOM Elements
    const figmaLinkInput = document.getElementById("figmaLink");
    const analyzeBtn = document.getElementById("analyzeBtn");
    const resultsSection = document.getElementById("resultsSection");
    const figmaError = document.getElementById("figmaError");
    const newAnalysisBtn = document.getElementById("newAnalysisBtn");
    const exportBtn = document.getElementById("exportBtn");
    
    // Metrics elements
    const layerCountEl = document.getElementById("layerCount");
    const colorCountEl = document.getElementById("colorCount");
    const fontCountEl = document.getElementById("fontCount");
    const spacingScoreEl = document.getElementById("spacingScore");

    // Animation timings
    const METRIC_ANIMATION_DURATION = 1500;
    const TYPEWRITER_DELAY = 50;

    // Normalize Figma URL (handles both /file/ and /design/ formats)
    function normalizeFigmaUrl(url) {
        return url
            .replace('/design/', '/file/')  // Convert design URLs to file format
            .split('?')[0];                 // Remove query parameters
    }

    // Analysis function
    async function analyzeFigmaProject(url) {
        const normalizedUrl = normalizeFigmaUrl(url);
        const response = await fetch('http://127.0.0.1:5000/api/analyze', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ figmaUrl: normalizedUrl })
        });

        if (!response.ok) {
            throw new Error(await response.text());
        }

        return await response.json(); // Expects { layers, colors, fonts, spacingScore }
    }

    // Animate counting up a metric value
    function animateMetric(element, targetValue) {
        const duration = METRIC_ANIMATION_DURATION;
        const start = 0;
        const increment = targetValue / (duration / 16); // 60fps
        let current = start;
        const timer = setInterval(() => {
            current += increment;
            if (current >= targetValue) {
                clearInterval(timer);
                current = targetValue;
            }
            element.textContent = Math.floor(current);
        }, 16);
    }

    // Handle analyze button click
    analyzeBtn.addEventListener("click", async () => {
        const url = figmaLinkInput.value.trim();
        figmaError.textContent = "";

        // Validation
        if (!url) {
            figmaError.textContent = "✨ Please enter a Figma project URL";
            figmaLinkInput.focus();
            return;
        }

        if (!url.startsWith("https://www.figma.com/file/") && 
            !url.startsWith("https://www.figma.com/design/")) {
            figmaError.textContent = "🔗 Please enter a valid Figma file URL";
            figmaLinkInput.focus();
            return;
        }

        // UI Loading State
        analyzeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Working Magic...';
        analyzeBtn.disabled = true;
        figmaLinkInput.disabled = true;

        try {
            const results = await analyzeFigmaProject(url);
            
            // Animate results
            animateMetric(layerCountEl, results.layers);
            animateMetric(colorCountEl, results.colors);
            animateMetric(fontCountEl, results.fonts);
            
            // Special animation for percentage
            let currentScore = 0;
            const scoreInterval = setInterval(() => {
                currentScore += 1;
                spacingScoreEl.textContent = `${currentScore}%`;
                if (currentScore >= results.spacingScore) {
                    clearInterval(scoreInterval);
                }
            }, METRIC_ANIMATION_DURATION / results.spacingScore);

            // Show results section with animation
            resultsSection.classList.remove("hidden");
            resultsSection.style.animation = "fadeIn 0.6s ease-out";

            // Success state
            analyzeBtn.innerHTML = '<i class="fas fa-check-circle"></i> Magic Complete!';
            setTimeout(() => {
                analyzeBtn.innerHTML = '<i class="fas fa-sparkles"></i> Generate Magic';
            }, 2000);

        } catch (error) {
            console.error("Analysis error:", error);
            figmaError.textContent = "🔮 The magic failed! " + error.message;
            analyzeBtn.innerHTML = '<i class="fas fa-redo"></i> Try Again';
        } finally {
            analyzeBtn.disabled = false;
            figmaLinkInput.disabled = false;
        }
    });

    // Handle new analysis button
    newAnalysisBtn.addEventListener("click", () => {
        // Reset UI
        resultsSection.classList.add("hidden");
        figmaLinkInput.value = "";
        figmaLinkInput.disabled = false;
        figmaLinkInput.focus();
        
        // Reset metrics
        layerCountEl.textContent = "0";
        colorCountEl.textContent = "0";
        fontCountEl.textContent = "0";
        spacingScoreEl.textContent = "0%";
    });

    // Handle export button
    exportBtn.addEventListener("click", () => {
        // Create export
        exportBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Exporting...';
        
        setTimeout(() => {
            exportBtn.innerHTML = '<i class="fas fa-file-export"></i> Export Report';
            
            // Create and trigger download
            const blob = new Blob(["Figma Analysis Report\n\n" +
                                 `Layers: ${layerCountEl.textContent}\n` +
                                 `Colors: ${layerCountEl.textContent}\n` +
                                 `Fonts: ${fontCountEl.textContent}\n` +
                                 `Consistency: ${spacingScoreEl.textContent}`], 
                                { type: 'text/plain' });
            
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'figma-analysis-report.txt';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 1000);
    });

    // Bonus: Add a typewriter effect for any element
    function typeWriter(element, text, speed) {
        let i = 0;
        element.textContent = "";
        
        function type() {
            if (i < text.length) {
                element.textContent += text.charAt(i);
                i++;
                setTimeout(type, speed);
            }
        }
        
        type();
    }
});